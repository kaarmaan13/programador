<style type="text/css">
#contenido {
font-size:11px;
}
#contenido .col1 {
float:left;
width:140px;
padding:3px 0px 3px 12px;
}
#contenido .col2 {
float:left;
width:400px;
padding:3px 0px 3px 12px;
color:#1489c7;
}
#contenido .col2 a {
color:#C33;
text-decoration:underline;
}
#contenido input.botonbusqueda {
border:2px solid #122F67;
padding:2px 2px 2px 2px;
background-color:#A1B2D3;
color:#142E6A;
font-weight:bold;
}
</style>
	<!-- contenido -->
<?	$result=mysql_query("SELECT * FROM contactos WHERE idcontacto=".$_REQUEST["idcontacto"]);
	$row=mysql_fetch_array($result);
?>
	<div class="esta">Est� en: <strong>Contactos web / Ver datos de <? echo $row["nombre"]." ".$row["apellidos"]; ?></strong></div>
	<div id="contenido" style="width:765px">
	<form id="formu" method="post" action="index.php?site=contactos&action=custom">
	<div class="fondointro">
		<input type="submit" name="Submit" value="&lt;&lt; Volver" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </form>
	</div>
    <br />
	<div class="col1">� Fecha Contacto:</div><div class="col2"><? echo date("d-m-Y H:i:s", strtotime($row["fechaenvio"])); ?></div><br class="sep" />
	<div class="col1">� Nombre:</div><div class="col2"><? echo $row["nombre"]; ?></div><br class="sep" />
	<div class="col1">� Apellidos:</div><div class="col2"><? echo $row["apellidos"]; ?></div><br class="sep" />
	<div class="col1">� E-mail:</div><div class="col2"><a href="mailto:<? echo $row["email"]; ?>"><? echo $row["email"]; ?></a></div><br class="sep" />
	<div class="col1">� Tel�fono:</div><div class="col2"><? echo $row["telefono"]; ?></div><br class="sep" />
    <div class="col1">� Recibir Newsletters:</div><div class="col2"><? if($row["newsletter"] == 1) echo "S�"; else echo "No"; ?></div><br class="sep" />
	<div class="col1">� Comentarios:</div><div class="col2"><? echo $row["comentarios"]; ?></div><br class="sep" />
	</div>