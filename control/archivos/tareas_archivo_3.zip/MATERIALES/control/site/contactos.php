<style type="text/css">
#contenido {
width:750px;
}
.scroll {
width: 750px;
height: 420px;
overflow: auto;
clear:both;
text align: center;
margin :auto;
}
#contenido .encab {
width:750px;
font-size:9px;
}
#contenido .encab .encab_1 {
float:left;
width:70px;
background-color:#000000;
color:#ffffff;
padding:3px 0px 3px 12px;
}
#contenido .encab .encab_2 {
float:left;
width:80px;
background-color:#000000;
color:#ffffff;
padding:3px 0px 3px 7px;
}
#contenido .encab .encab_3 {
float:left;
width:120px;
background-color:#000000;
color:#ffffff;
padding:3px 0px 3px 7px;
}
#contenido .encab .encab_4 {
float:left;
width:190px;
background-color:#000000;
color:#ffffff;
padding:3px 0px 3px 7px;
}
#contenido .encab .encab_5 {
float:left;
width:90px;
background-color:#000000;
color:#ffffff;
padding:3px 0px 3px 7px;
}
#contenido .encab .encab_6 {
float:left;
width:110px;
background-color:#000000;
color:#ffffff;
padding:3px 0px 3px 15px;
}
#contenido .fila {
width:733px;
font-size:9px;
}
#contenido .fila a {
font-weight:bold;
width:733px;
}
#contenido .fila .col_1 {
background-image:url(images/flechita.gif);
background-repeat:no-repeat;
float:left;
width:70px;
padding:3px 0px 3px 12px;
}
#contenido .fila .col_2 {
float:left;
width:80px;
padding:3px 0px 3px 7px;
}
#contenido .fila .col_3 {
float:left;
width:120px;
padding:3px 0px 3px 7px;
}
#contenido .fila .col_4 {
float:left;
width:190px;
padding:3px 0px 3px 7px;
}
#contenido .fila .col_5 {
float:left;
width:90px;
padding:3px 0px 3px 7px;
}
#contenido .fila .col_6 {
float:left;
width:110px;
padding:3px 0px 3px 30px;
}
#contenido input.botonbusqueda {
border:2px solid #000;
padding:2px 2px 2px 2px;
background-color:#bcac80;
color:#000000;
font-weight:bold;
}
</style>
<script type="text/javascript">
function enviar() {
	document.getElementById("formu").submit();
}
</script>
	<!-- arriba -->
	<script type="text/javascript">escribesuperior();</script>
	<!-- /arriba -->
	
	<!-- menu -->
	<script type="text/javascript">escribemenu();</script>
	<!-- /menu -->
	
	<div class="esta">Est� en: <strong>Contactos web / Ver Contactos web</strong></div>
	<!-- contenido -->
	<div id="contenido" style="width:750px">
		<!-- FILTROS -->
		<form id="formu" method="post" action="index.php?site=contactos&action=custom">
			<p><strong style="font-weight:normal;color:#000000">Filtro</strong> Apellidos:</p><br class="sep" />
			<input type="text" name="apellidos" value="<? if($_REQUEST["apellidos"]) echo $_REQUEST["apellidos"]; ?>" size="65" />
			<p><strong style="font-weight:normal;color:#000000">Filtro</strong> E-mail:</p><br class="sep" />
			<input type="text" name="email" value="<? if($_REQUEST["email"]) echo $_REQUEST["email"]; ?>" size="65" />
			<p><strong style="font-weight:normal;color:#000000">Filtro</strong> Tel�fono:</p><br class="sep" />
			<input type="text" name="telefono" value="<? if($_REQUEST["telefono"]) echo $_REQUEST["telefono"]; ?>" size="65" />
			<p><strong style="font-weight:normal;color:#000000">Filtro</strong> Fechas:</p><br class="sep" />
			<? 
				// Restamos inicialmente una semana al d�a actual. Si vuelve un valor de la consulta, lo tomamos
				if($_REQUEST["fechafin"] == "") $fechafin=date("Y-m-d"); else $fechafin=$_REQUEST["fechafin"];
				if($_REQUEST["fechainicio"] == "") $fechainicio=date("Y-m-d", strtotime("$fechafin -14 day"));  else $fechainicio=$_REQUEST["fechainicio"];
			?>
			<script type="text/javascript" src="includes/calendar/calendarDateInput.js"></script>
			<div style="float:left;padding:7px 5px 0px 0px;font-weight:normal">Del</div><div style="float:left"><script "text/javascript">DateInput('fechainicio', true, 'YYYY-mm-dd', '<? echo date("Y", strtotime($fechainicio))."-".date("m", strtotime($fechainicio))."-".date("d", strtotime($fechainicio)) ?>');</script></div>
			<div style="float:left;padding:7px 5px 0px 5px;font-weight:normal">al</div><div style="float:left"><script type="text/javascript">DateInput('fechafin', true, 'YYYY-mm-dd', '<? echo date("Y", strtotime($fechafin))."-".date("m", strtotime($fechafin))."-".date("d", strtotime($fechafin)) ?>');</script></div>
			<div style="float:left;margin-left:20px"><input type="button" name="Submit" onclick="javascript:enviar();" class="botonbusqueda" value="Nueva B�squeda" /></div>
			<br class="sep" />
		</form>
		<!-- /FILTROS -->
		<div class="seppuntos"></div><br />
		<div class="encab" style="width:750px">
			<div class="encab_1">Fecha Contacto</div>
			<div class="encab_2">Nombre</div>
			<div class="encab_3">Apellidos</div>
			<div class="encab_4">Email</div>
			<div class="encab_5">Tel�fono</div>
            <div class="encab_6">Recibir Newsletters</div>
			<div class="sep"><img src="../images/sizer.gif" alt="" width="1" height="1" /></div>
		</div>
		<div class="scroll">
<?	$query = "SELECT * FROM contactos ";
	$query .=" WHERE fechaenvio >= '".$fechainicio." 00:00:00' AND fechaenvio <= '".$fechafin." 24:00:00'";
	if ($_REQUEST["apellidos"] != "") $query .=" AND apellidos like '%".$_REQUEST["apellidos"]."%'";
	if ($_REQUEST["email"] != "") $query .=" AND email like '%".$_REQUEST["email"]."%'";
	if ($_REQUEST["telefono"] != "") $query .=" AND telefono like '%".$_REQUEST["telefono"]."%'";
	$query.= " ORDER BY fechaenvio DESC, apellidos, nombre";
	$result=mysql_query($query);
	$i=0;
	while($row=mysql_fetch_array($result)) {
		$i++;
		if($i%2 == 0) $color="#d0d0d2";
		else $color="#FFFFFF";
?>
            <div class="fila" style="background-color:<? echo $color ?>">
                <a href="index.php?site=ver_contacto&action=custom&idcontacto=<? echo $row["idcontacto"] ?>">
                    <div class="col_1"><? echo date("d-m-Y", strtotime($row["fechaenvio"]))."<br /><strong style='color:#005f92'>".date("H:i:s", strtotime($row["fechaenvio"]))."</strong>"; ?></div>
                    <div class="col_2"><? echo $row["nombre"] ?></div>
                    <div class="col_3"><? echo $row["apellidos"] ?></div>
                    <div class="col_4"><? echo $row["email"] ?></div>
                    <div class="col_5"><? echo $row["telefono"] ?></div>
                    <? if ($row["newsletter"]==1) { ?>
                    	<div class="col_6"><? echo 'SI' ?></div>
                    <? } else { ?>
                    	<div class="col_6"><? echo 'NO' ?></div>
                    <? } ?>
                    <div class="sep"><img src="../images/sizer.gif" alt="" width="1" height="1" /></div>
                </a>
            </div>
<?	} ?>
		</div>
	</div>
	<!-- /contenido -->
	<div class="sep"><img src="../images/sizer.gif" alt="" width="1" height="1" \></div>