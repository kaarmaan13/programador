<? include "php/conexion.php" ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Bagdelux.com. Venta y compra de bolsos de marca, complementos, zapatos, cinturones, carteras, bandoleras, pulseras, monederos. Bolsos de lujo. Dise�adores. Segunda mano - Contacto</title>
<? include "includes/metas.php" ?>
<style type="text/css">
#cont #contenido #central .titular {
	width:110px;
}
</style>
<script type="text/javascript"> 
function validarEmail(valor) {
	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(valor)){
		return (true)
	} else {
		return (false);
	}
}
function enviar() {
	/* Nombre */
	if (document.getElementById('formu').nombre.value == '') {
		alert('Por favor, debe introducir el campo \'Nombre\'');
		document.getElementById('formu').nombre.focus();
		return;
	}
	/* Apellidos */
	if (document.getElementById('formu').apellidos.value == '') {
		alert('Por favor, debe introducir el campo \'Apellidos\'');
		document.getElementById('formu').apellidos.focus();
		return;
	}
	/* E-mail o Tel�fono */
	if ((document.getElementById('formu').email.value == '') && (document.getElementById('formu').telefono.value == '')) {
		alert('Por favor, debe introducir su \'Correo Electr�nico\' o \'Tel�fono\' para contactarle');
		document.getElementById('formu').email.focus();
		return;
	}
	// Validar E-mail
	if((document.getElementById('formu').email.value != '') && (!validarEmail(document.getElementById("formu").email.value))) {
		alert('Por favor, debe introducir un \"E-mail"\ v�lido');
		document.getElementById('formu').email.focus();
		return;		
	}
	/* Correo obligatorio si desea recibir Newsletters */
	if ((document.getElementById('formu').newsletter) && (document.getElementById('formu').email.value == '')) {
		alert('Si desea recibir Newsletters debe rellenar el campo \'Correo Electr�nico\'');
		document.getElementById('formu').email.focus();
		return;
	}
	/* Comentarios */
	if (document.getElementById('formu').comentarios.value == '') {
		alert('Por favor, debe introducir el campo \'Comentarios\'');
		document.getElementById('formu').comentarios.focus();
		return;
	}
	
	document.getElementById('formu').submit();
}
</script>
</head>  
<body>
<?	$result=mysql_query("SELECT * FROM contacto");
	$row=mysql_fetch_array($result);
?>
	<div id="cont">
<? include "includes/superior.php" ?>
        <div id="contenido">
			<div id="central">
            	<div class="titular">CONTACTO</div>
                <div class="textolargo">
	               	<? echo $row["texto"] ?>
                </div>
            	<div class="bloquelargo">
                	<div class="subtitular">FORMULARIO DE CONTACTO</div>
                    <div class="texto">
                        <img src="images/puntonegro.gif" alt="" /> <strong>Nombre</strong><br />
                        <div><form id="formu" method="post" action="enviocontacto.php">
                        <input type="text" name="nombre" value="<? echo $_REQUEST["nombre"] ?>"  /><br />
                        <img src="images/puntonegro.gif" alt="" /> <strong>Apellidos</strong><br />
                        <input type="text" name="apellidos" value="<? echo $_REQUEST["apellidos"] ?>"  /><br />
                        <strong>Correo Electr�nico</strong><br />
                        <input type="text" name="email" value="<? echo $_REQUEST["email"] ?>"  /><br />
                        <strong>Tel�fono</strong><br />
                        <input type="text" name="telefono" style="width:170px" value="<? echo $_REQUEST["telefono"] ?>"  /><br />
                        <img src="images/puntonegro.gif" alt="" /> <strong>Comentarios</strong><br />
                        <textarea name="comentarios" style="width:550px;height:80px"><? echo $_REQUEST["comentarios"] ?></textarea><br />
                        <input type="checkbox" name="newsletter" class="checkcontacto" /> <strong>S�, deseo recibir la Newsletter de Bagdelux</strong><br />
                        </form></div>
                        <div class="boton"><a href="javascript:enviar()">Enviar</a></div>
                    </div>
                </div>
            	<div class="foto">
                    <img src="fotos/<? echo $row["foto"] ?>" alt="Contacto" />
                </div>
                <br class="sep" />
			</div>
            <br class="sep" />
        </div>
<? include "includes/inferior.php" ?>
    </div>
</body>
</html>
<? include "php/desconexion.php" ?>