<? include "php/conexion.php" ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Bagdelux.com. Venta y compra de bolsos de marca, complementos, zapatos, cinturones, carteras, bandoleras, pulseras, monederos. Bolsos de lujo. Dise�adores. Segunda mano - <? if ($respuesta != "errorenvio") { ?>Formulario de contacto enviado satisfactoriamente<? } else { ?>Error en el env�o de su Formulario de contacto<? } ?></title>
<? include "includes/metas.php" ?>
</head>  
<body>
	<div id="cont">
<? include "includes/superior.php" ?>
        <div id="contenido">
			<div id="central">
            	<div class="titular">CONTACTO</div>
                <div class="bloque">
                	<div class="subtitular"><? if ($respuesta != "errorenvio") { ?>Formulario de contacto enviado satisfactoriamente<? } else { ?>Error en el env�o de su Formulario de contacto<? } ?></div>
                </div>
                <br class="sep" />
                <div style="padding:10px 0px 0px 20px">
					<? if ($respuesta != "errorenvio") { ?>
                    Estimado/a usuario/a,<br />
                    Hemos recogido correctamente su formulario de contacto. En breve nos dirigiremos a usted.<br /><br />
                    Gracias por confiar en nosotros,<br />
                    <? } else { ?>
                    Ha ocurrido un error en su env�o de formulario de contacto. Por favor, vuelva a intentarlo pasados unos minutos o p�ngase en contacto con nosotros por tel�fono.<br /><br />
                    Atentamente,<br />
                    <? } ?>
                    El equipo de <strong>Bagdelux.com</strong><br /><br /><br />
                </div>
			</div>
            <br class="sep" />
        </div>
<? include "includes/inferior.php" ?>
    </div>
</body>
</html>
<? include "php/desconexion.php" ?>