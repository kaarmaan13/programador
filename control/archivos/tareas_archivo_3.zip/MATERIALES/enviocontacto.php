<?
if($_REQUEST["nombre"] != "") {
	include "php/conexion.php";
	include "php/class.phpmailer.php";
			
	// Recogida de datos
	$nombre=$_POST["nombre"];
	$apellidos=$_POST["apellidos"];
	$email=$_POST["email"];
	$telefono=$_POST["telefono"];
	$comentarios=$_POST["comentarios"];
	$newsletter=$_POST["newsletter"];
	$fechaenvio=date("Y-m-d H:i:s");
	
	// INSERCI�N EN BBDD
	if ($newsletter) { 
		$suscripcionnewsletter=SI;
		$result_news=mysql_query("INSERT INTO usuariosnewsletter(email, fechaenvio, activo) VALUES ('".$email."', '".$fechaenvio."', 1)");
		$newsletter=1;
	} else {
		$suscripcionnewsletter=NO;
		$newsletter=0;
	}
	$result=mysql_query("INSERT INTO contactos (nombre, apellidos, email, telefono, comentarios, newsletter, fechaenvio) VALUES ('$nombre', '$apellidos', '$email', '$telefono', '$comentarios', '$newsletter', '$fechaenvio')");
	$idcontacto=mysql_insert_id();
	
	// ENV�O DE EMAIL
	require_once("php/class.phpmailer.php");
	$mail = new phpmailer();
	$mail->From = "bagdelux@bagdelux.com";
	$mail->FromName = "Bagdelux.com";
	
	$mail->Subject = "Contacto enviado desde Bagdelux.com";
	
	//variables globales
	$ruta = "http://www.bagdelux.com/";
	
	//contenido del Mail en HTML
	$texto = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';
	$texto .= '<html xmlns="http://www.w3.org/1999/xhtml">';
	$texto .= '<head>';
	$texto .= '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />';
	$texto .= '<style type="text/css">';
	$texto .= 'body { font-family: Arial, Helvetica, sans-serif; font-size:12px;background-color:#FFFFFF }';
	$texto .= '</style>';
	$texto .= '<title>Contacto enviado desde Bagdelux.com</title>';
	$texto .= '</head>';
	$texto .= '	<body style="font-family: Arial, Helvetica, sans-serif; font-size:12px;background-color:#FFFFFF" bgcolor="#FFFFFF">
	<table width="620" cellpadding="0" cellspacing="0" align="center">
		<tr>
			<td colspan="3" width="620" height="30"></td>
		</tr>
		<tr>
			<td width="620" height="20" align="center" style="font-size:11px;font-weight:bold">Si no puede visualizar este mensaje de forma correcta pulse <a href="'.$ruta.'email/enviocontacto.php?idcontacto='.$idcontacto.'">aqu�</a></strong></td>
		</tr>
	</table>
	<table width="620" cellpadding="0" cellspacing="0" align="center">
	
	</table>
	<table width="620" cellpadding="0" cellspacing="0" align="center">
		<tr>
			<td background="'.$ruta.'email/images/superior.gif" width="620" height="20"></td>
		</tr>
	</table>
	<table background="'.$ruta.'email/images/fondo.gif" width="620" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td width="620" height="10" align="left" colspan="3">&nbsp;</td>
		</tr>
		<tr>
			<td width="40" height="48" align="left">&nbsp;</td>
			<td width="580" height="48" colspan="2" align="left"><a href="'.$ruta.'"><img src="'.$ruta.'images/logo.gif" alt="" border="0" /></a></td>
		</tr>
		<tr>
			<td width="620" height="10" align="left" colspan="3">&nbsp;</td>
		</tr>
	</table>
	<table background="'.$ruta.'email/images/fondo2.gif" width="620" align="center" cellpadding="0" cellspacing="0">
		<tr>        	
			<td width="18" height="30" align="left"></td>
			<td width="584" height="30" align="left" bgcolor="#000" style="color:#FFFFFF;font-size:19px">&nbsp;&nbsp;&nbsp;&nbsp;Contacto enviado desde Bagdelux.com</td>
			<td width="18" height="30" align="left"></td>
		</tr>
	</table>
	<table background="'.$ruta.'email/images/fondo.gif" width="620" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td width="620" height="10" align="center" colspan="3"></td>
		</tr>
		<tr>        	
			<td width="40" height="200" align="left">&nbsp;</td>
			<td width="540" height="200" align="left" style="font-family: Arial, Helvetica, sans-serif; font-size:12px">
				Se ha recibido un contacto con los siguientes datos:<br /><br />
				Nombre: <strong>'.$nombre.'</strong><br />
				Apellidos: <strong>'.$apellidos.'</strong><br />
				Correo electr�nico: <strong>'.$email.'</strong><br />
				Tel�fono: <strong>'.$telefono.'</strong><br />
				Comentarios: <strong>'.$comentarios.'</strong><br />
				Desea recibir Newsletters: <strong>'.$suscripcionnewsletter.'</strong><br />
				Fecha env�o: <strong>'.date("d-m-Y H:i:s", strtotime($fechaenvio)).'</strong><br /><br />
			</td>
			<td width="40" height="200" align="left">&nbsp;</td>
		</tr>
		<tr>
			<td width="620" height="20" align="center" colspan="3"></td>
		</tr>
	</table>
	<table background="'.$ruta.'email/images/fondo2.gif" width="620" align="center" cellpadding="0" cellspacing="0">
		<tr>        	
			<td width="18" height="3" align="left"></td>
			<td width="584" height="3" align="left" bgcolor="#000"></td>
			<td width="18" height="3" align="left"></td>
		</tr>
	</table>
	<table background="'.$ruta.'email/images/fondo2.gif" width="620" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td width="40" height="260" align="left">&nbsp;</td>
			<td width="540" height="260" style="background-color:#bcab7f;font-size:10px">
				El presente correo electr�nico y, en su caso, cualquier fichero anexo al mismo, contiene informaci�n de car�cter CONFIDENCIAL dirigida en exclusiva a su/s destinatario/s.<br /><br />
				Queda prohibida su divulgaci�n, copia o distribuci�n a terceros sin la previa autorizaci�n escrita de BAG de LUX, S.L. (en adelante BAGDELUX).<br /><br />
				En caso de que usted haya recibido este correo electr�nico por error, rogamos nos notifique inmediatamente esta circunstancia, mediante su reenv�o a la direcci�n electr�nica del remitente y proceda a su posterior borrado.<br /><br />
				BAGDELUX garantiza la adopci�n de las medidas necesarias para el tratamiento de los datos de car�cter personal de conformidad con lo establecido en la Ley Org�nica 15/1999 de Protecci�n de Datos de Car�cter Personal.<br /><br />
				Los datos personales que nos facilite as� como su direcci�n de correo electr�nico ser�n incluidos en los ficheros "Clientes" y "Prospecci�n comercial", propiedad de BAGDELUX S.L., cuyas finalidades son las de gestionar los datos referidos a clientes, y la gesti�n de datos referidos a actividades y campa�as comerciales (e-mailing, web, correo postal, sms, carteler�a, etc), respectivamente. Usted puede ejercitar sus derechos de Acceso, Rectificaci�n, Cancelaci�n y Oposici�n dirigi�ndose por escrito a la direcci�n de correo electr�nico <a href="mailto:bagdelux@bagdelux.com">bagdelux@bagdelux.com</a> (indicando en el asunto "LOPD").
			</td>
			<td width="40" height="260" align="left">&nbsp;</td>
		</tr>        
	</table>
	<table width="620" cellpadding="0" cellspacing="0" align="center">
		<tr>
			<td background="'.$ruta.'email/images/inferior.gif" width="620" height="20"></td>
		</tr>
	</table>
	</body>';
	$texto .= '</html>';
	
	//Contenido del Mail en "Texto Plano"
	$atexto .= "Contacto enviado desde Bagdelux.com\n\n";
	$atexto .= "Se ha recibido un  contacto con los siguientes datos:\n\n";
	$atexto .= "Nombre: ".$nombre."\n";
	$atexto .= "Apellidos: ".$apellidos."\n";
	$atexto .= "Correo electr�nico: ".$email."\n";
	$atexto .= "Tel�fono: ".$telefono."\n";
	$atexto .= "Comentarios: ".$comentarios."\n";
	$atexto .= "Desea recibir Newsletters: ".$suscripcionnewsletter."\n";
	$atexto .= "Fecha env�o: ".$fechaenvio."\n\n";
	$atexto .= "---------------------------------------------------\n";
	$atexto .= "El presente correo electr�nico y, en su caso, cualquier fichero anexo al mismo, contiene informaci�n de car�cter CONFIDENCIAL dirigida en exclusiva a su/s destinatario/s.<br /><br />
			Queda prohibida su divulgaci�n, copia o distribuci�n a terceros sin la previa autorizaci�n escrita de BAG de LUX, S.L. (en adelante BAGDELUX).<br /><br />
			En caso de que usted haya recibido este correo electr�nico por error, rogamos nos notifique inmediatamente esta circunstancia, mediante su reenv�o a la direcci�n electr�nica del remitente y proceda a su posterior borrado.<br /><br />
			BAGDELUX garantiza la adopci�n de las medidas necesarias para el tratamiento de los datos de car�cter personal de conformidad con lo establecido en la Ley Org�nica 15/1999 de Protecci�n de Datos de Car�cter Personal.<br /><br />
			Los datos personales que nos facilite as� como su direcci�n de correo electr�nico ser�n incluidos en los ficheros \"Clientes\" y \"Prospecci�n comercial\", propiedad de BAGDELUX S.L., cuyas finalidades son las de gestionar los datos referidos a clientes, y la gesti�n de datos referidos a actividades y campa�as comerciales (e-mailing, web, correo postal, sms, carteler�a, etc), respectivamente. Usted puede ejercitar sus derechos de Acceso, Rectificaci�n, Cancelaci�n y Oposici�n dirigi�ndose por escrito a la direcci�n de correo electr�nico bagdelux@bagdelux.com (indicando en el asunto \"LOPD\").\n";
	$atexto .= "---------------------------------------------------\n\n";
	$atexto .= "Tambi�n puede visualizar el email en HTML en esta direcci�n URL: ".$ruta."email/enviocontacto.php?idcontacto=".$idcontacto;
	
	$mail->Body = $texto;
	$mail->AltBody = $atexto;
	$mail->AddAddress("bagdelux@bagdelux.com");
	
	$mail->Timeout=120;
	
	$exito = $mail->Send();
	
	if ($mail->ErrorInfo=="SMTP Error: Data not accepted") {
	   $exito=true;
	}
	
	$hayerror="no";
	
	if(!$exito) {
		$hayerror="si";
	}
	
	$mail->ClearAddresses();
	
	if ($hayerror=="si") header("location: contacto_ok.php?respuesta=errorenvio");
	else header("location: contacto_ok.php?respuesta=ok");
	
	include "php/desconexion.php";
}
?>